
var contacts = [
    {name:'Eric Pogue v2', address:'2760 South Highland Ave', city:'Lemont', state:'IL', zip:'60148'},
    {name:'Ted', address:'2760 South Highland Ave', city:'Lemont', state:'IL', zip:'60148'},
    {name:'Sanjay', address:'2760 South Highland Ave', city:'Lemont', state:'IL', zip:'60148'},
    {name:'Edward', address:'2760 South Highland Ave', city:'Lemont', state:'IL', zip:'60148'},
]; 

currentContact = contacts[0];

function viewCurrentContact() {
    console.log('veiwCurrentContact()');
    document.getElementById("name").value = currentContact.name;   
    document.getElementById("address").value = currentContact.address;
    document.getElementById("city").value = currentContact.city;   
    document.getElementById("state").value = currentContact.state;
    document.getElementById("zip").value = currentContact.zip;  
}

function previous() {
    console.log('previous()'); 
}

function next() {
    console.log('next()');  
}

function add() {
    console.log('add()');
}

function remove() {
    console.log('remove()');
}

