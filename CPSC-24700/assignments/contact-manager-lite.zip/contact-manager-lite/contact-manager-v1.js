

function loadContacts() {
    console.log('loadContacts()');
    document.getElementById("name").value = 'Eric Pogue';   
    document.getElementById("address").value = '2760 South Highland Ave';
    document.getElementById("city").value = 'Lemont';   
    document.getElementById("state").value = 'IL';
    document.getElementById("zip").value = '60148';  
}

function previous() {
    console.log('previous()'); 
}

function next() {
    console.log('next()');  
}