var gMap;

// initMap is a callback function that is initiated as part of the Google Maps API call at the bottom.
function initMap() {
    // Create a new map and assign it to gMap
    gMap = new google.maps.Map(document.getElementById('myMapID'), {
        center: {lat: 41.878, lng: 10}, zoom: 3});

    // Add a marker for Canoe Bay, WI    
    var marker = new google.maps.Marker({position:{lat:45.3306,lng:-91.4918}, map:gMap});

    // Add a second marking with a custom icon, an Info window, and a listener.
    var marker2 = new google.maps.Marker({position:{lat:36.3932,lng:25.4615}, map:gMap});
    marker2.setIcon('https://maps.google.com/mapfiles/kml/shapes/info-i_maps.png');

    var infoWindow = new google.maps.InfoWindow({content:'Santorini, Greece'});
    marker2.addListener('click', function() {
        infoWindow.open(gMap, marker2);
    });

    // Note that several message boards suggested using 'idle' instead of 'bounds_changed' because 
    // 'bounds_changed' gets called over and over when the user drags the map.
    google.maps.event.addListener(gMap, 'idle', function() {
        UpdateGame()
    });
}

function UpdateGame() {
    console.log('function UpdateGame() google-maps-step-04!');
    var zoomLevel = gMap.getZoom()
    var inBounds = false;

    // Check if Canoe Bay, WI is in the currently displayed map
    if (gMap.getBounds().contains({lat:45.3306,lng:-91.4918})) {
        inBounds = true;
    }

    console.log("inBounds:"+inBounds+" zoomLevel:"+zoomLevel);

    // We likely will need to update our "Hint" and "Score" fields dynamically here based on window location
    // and inBounds or not.

    // We will also need to add our marker when the user finds one and clicks on it.
    
    // Finally, we will need to update to a new location or let them know they won. 
}
