var gMap;

// initMap is a callback function that is initiated as part of the Google Maps API call at the bottom.
function initMap() {
    // Create a new map and assign it to gMap
    gMap = new google.maps.Map(document.getElementById('myMapID'), {
        center: {lat: 41.878, lng: 10}, zoom: 3});

    var marker = new google.maps.Marker({position:{lat:45.3306,lng:-91.4918}, map:gMap});

    var marker2 = new google.maps.Marker({position:{lat:36.3932,lng:25.4615}, map:gMap});
    marker2.setIcon('https://maps.google.com/mapfiles/kml/shapes/info-i_maps.png');
    var infoWindow = new google.maps.InfoWindow({content:'Santorini, Greece'});
    marker2.addListener('click', function() {
        infoWindow.open(gMap, marker2);
    });
}

function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1) ) + min;
}

function random() {
    console.log('function random() being called in google-maps-step-02!');
    document.getElementById("dice-1").value = getRandomInteger(1, 6);   
    document.getElementById("dice-2").value = getRandomInteger(1, 6);
    document.getElementById("dice-3").value = getRandomInteger(1, 6);   
    document.getElementById("dice-4").value = getRandomInteger(1, 6);
    document.getElementById("dice-5").value = getRandomInteger(1, 6);   
}